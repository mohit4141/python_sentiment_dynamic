def func(var):
    return "hello %s" %var