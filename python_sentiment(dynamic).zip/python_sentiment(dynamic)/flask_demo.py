import sys, os
sys.path.insert(0, os.getcwd()+"/Subdirectory") 
import sent_analyser
import twint_demo
import vadersentiment
import wcloud
import preprocessor
# import random1
# from asyncio import new_event_loop, set_event_loop

from flask import Flask, redirect, url_for, request, render_template
app = Flask(__name__)
# app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

@app.route('/')
def success():
   return render_template('index.html')

@app.route('/index',methods = ['POST', 'GET'])
def login():
   if request.method == 'POST':
      hashtag = request.form['message']
      # tw=twint_demo.scraper(hashtag)
      # pre=preprocessor.prepper(hashtag)
      # comp1,neg1,pos1,neu1 = vadersentiment.vader_sent(hashtag)
      # clo=wcloud.cloud(hashtag,comp1,neg1,pos1,neu1)
      var = sent_analyser.analyzer(hashtag)
      # print
      
      return render_template('sa3.html', cloud = var)  

@app.after_request
def add_header(r):
    """
    Add headers to both force latest IE rendering engine or Chrome Frame,
    and also to cache the rendered page for 10 minutes.
    """
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    r.headers['Cache-Control'] = 'public, max-age=0'
    return r  
     
if __name__ == '__main__':
   app.debug = True
   # app.config["CACHE_TYPE"] = "null"

   # app.run()
   # asyncio.set_event_loop(asyncio.new_event_loop())

   app.run(threaded=True, use_reloader=True)
